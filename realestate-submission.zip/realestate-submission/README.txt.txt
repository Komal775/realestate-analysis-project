Project: Real Estate Analysis

Backend: Django REST API
Frontend: React (Vite)

How to run backend:
1. cd realestate-backend
2. python -m venv venv
3. venv\Scripts\activate
4. pip install -r requirements.txt
5. python manage.py runserver

How to run frontend:
1. cd realestate-frontend
2. npm install
3. npm run dev

Dataset:
data/realestate.xlsx
